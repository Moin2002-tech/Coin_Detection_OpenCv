#pragma once
//OpenCv includes


#include<opencv2/opencv.hpp>
#include<opencv2/imgproc.hpp>
#include<opencv2/core.hpp>
#include<opencv2/highgui.hpp>



cv::Mat displayConnectedComponents(cv::Mat& im);

cv::Mat DisplayDetected(cv::Mat Image, std::vector<cv::KeyPoint> Keypoints);

void areaAndArcLength(std::vector<std::vector<cv::Point>> Contour);

void maxAreaOfContour(std::vector<std::vector<cv::Point>> Contours);