#include"DetectionHeader.hpp"
#include<iostream>
#include<vector>
#include<string>
using cv::Mat;
using std::cout;

int main() {
	//reading an Image
	std::string Path = "./Resourses/CoinsA.png";
	Mat Coins = cv::imread(Path);
	Mat copyCoin = Coins.clone();
	std::vector<Mat> channels;
	//spliting image to rgb;
	cv::split(copyCoin, channels);
	cout << "Blue == 1 , Green == 2, Red == 3"<<"\n";
	/*
	for (int i = 0; i < channels.size(); i++) {
		std::string windowName = "Coins" + std::to_string(i);
		cv::imshow(windowName, channels[i]);
	} */
	
	//Converting Image to Gray Scale

	Mat GrayCoins;
	cv::cvtColor(copyCoin, GrayCoins, cv::COLOR_BGR2GRAY);
	cv::imshow("grayCoin", GrayCoins);

	//perfoming  threshholding

	Mat src = GrayCoins.clone();
	Mat dst;
	int thresh = 55;
	int maxValue = 255;
	threshold(src, dst, thresh, maxValue, cv::THRESH_BINARY_INV);
	
	cv::imwrite("./Coin/BINARY_INVERSE.png", dst);
	//Dilating Image kSize = 2, kernel MORPH_CROSS


	int kernelSize = 2;
	Mat kernel1 = getStructuringElement(cv::MORPH_CROSS,
		cv::Size(kernelSize, kernelSize));

	Mat imageDilated;

	dilate(dst, imageDilated, kernel1);
	cv::imwrite("./Coin/Dilation1.png", imageDilated);
	
	//perfoming erotion, kernel = MORH_RECTANGLE

	int kSize2 = 2;
	Mat kernel2 = getStructuringElement(cv::MORPH_RECT,
		cv::Size(kSize2, kSize2));
	Mat imageErode;
	erode(imageDilated, imageErode, kernel2);
	cv::imwrite("./Coin/Erotion_of_Dilated_2.png", imageDilated);


	//performing erotion 2nd time for clear white blob in coins
	//kernel = MORPH_RECTANGLE

	int kSize3 = 2;
	Mat kernel3 = getStructuringElement(cv::MORPH_RECT,
		cv::Size(kSize3, kSize3));
	Mat imageErode2;
	erode(imageErode, imageErode2, kernel3);
	cv::imwrite("./Coin/Erotion_3.png",imageErode2);

	//performing Closing
	// Selecting a elliptical kernel
	int closingSize = 5;

	Mat element5 = cv::getStructuringElement(cv::MORPH_ELLIPSE, cv::Size(2 * closingSize + 1, 2 * closingSize + 1),cv::Point(closingSize, closingSize));

	Mat Closing;
	morphologyEx(imageErode2, Closing, cv::MORPH_CLOSE, element5, cv::Point(-1, -1), 3);
	cv::imwrite("./Coin/Closing_4.png", Closing);


	

	// Setup SimpleBlobDetector parameters.
	cv::SimpleBlobDetector::Params params;

	params.blobColor = 0;

	params.minDistBetweenBlobs = 2;

	// Filter by Area
	params.filterByArea = false;

	// Filter by Circularity
	params.filterByCircularity = true;
	params.minCircularity = 0.8;

	// Filter by Convexity
	params.filterByConvexity = true;
	params.minConvexity = 0.8;

	// Filter by Inertia
	params.filterByInertia = true;
	params.minInertiaRatio = 0.8;


	// Set up detector with params
	cv::Ptr<cv::SimpleBlobDetector> detector = cv::SimpleBlobDetector::create(params);
	
	//Detecting Coins

	// Detect blobs

	std::vector<cv::KeyPoint> keypoints;
	detector->detect(Closing, keypoints);


	// Print number of coins detected
	cout << "\n";
	cout << "Number of coin detected =" << keypoints.size()<<"\n";
	

	//Display the detected coins on original image
	cv::Mat detectedCoin = DisplayDetected(Coins, keypoints);
	//cv::imshow("functionsICreated", detectedCoin);




	Mat finalImage = Closing.clone();

	Mat finalImageInverted;
	int thresh1 = 0;
	int maxValue1 = 255;
	//bitwise_not(finalImage, finalImageInverted);

	threshold(finalImage, finalImageInverted, thresh, maxValue1, cv::THRESH_BINARY_INV);
	//cv::imshow("ClosingInverted", finalImageInverted);
	cv::imwrite("./Coin/ClosingInverted.png", finalImageInverted);



	//Performing Connected Component Analysis
	finalImageInverted.convertTo(finalImageInverted, CV_8U);
	Mat colorMap = displayConnectedComponents(finalImageInverted);
	//cv::imshow("colorMap", colorMap);
	cv::imwrite("./Coin/ColorMap.png",colorMap);
	
	//detecting Coin using Contours Detection

	//finding the contours

	std::vector<std::vector<cv::Point>> contours;
	std::vector<cv::Vec4i> hierarchy;


	findContours(Closing, contours, hierarchy, cv::RETR_LIST, cv::CHAIN_APPROX_SIMPLE);
	cout << std::endl;
	cout << "detected contours = " << contours.size()<<"\n";

	Mat imageCopy2 = Coins.clone();

	drawContours(imageCopy2, contours, -1, cv::Scalar(0, 255, 0), 5);

	cv::imshow("detectedContours", imageCopy2);
	cv::imwrite("./Coin/detecedCoinsNotPerfect.png", imageCopy2);

	//finding external contour, RETR_EXTERNAL
	std::vector<std::vector<cv::Point>> contours1;
	std::vector<cv::Vec4i> hierarchy1;
	Mat imageCopy3 = Coins.clone();
	Mat CopyGray = Closing.clone();



	findContours(CopyGray, contours1, hierarchy1, cv::RETR_EXTERNAL, cv::CHAIN_APPROX_SIMPLE);
	drawContours(imageCopy3, contours1, -1, cv::Scalar(0, 255, 0), 5);
	cout << "Number of contour found =" << contours1.size();



	//cv::imshow("externalContours", imageCopy3);
	cv::imwrite("./Coin/externalContours.png", imageCopy3);


	// Print area and perimeter of all contours


	areaAndArcLength(contours);

	// Print maximum area of contour


	maxAreaOfContour(contours);
	
  // This will be the box that we want to remove


	//remove contour

	cout << contours.size() << "\n";
	contours.erase(contours.begin() + 10);

	cout << contours.size();
	contours.erase(contours.begin() + 2);
	Mat imageCopy4 = Coins.clone();

	drawContours(imageCopy4, contours, -1, cv::Scalar(0, 255, 0), 5);

	//cv::imshow("noicesDetecedCoins", imageCopy4);

	cv::imwrite("./Coin/noicesDetectedCoin.png", imageCopy4);

	Mat imageCopy5 = Coins.clone();
	for (const auto& contour : contours) {
		cv::Point2f center;
		float radius;
		minEnclosingCircle(contour, center, radius);

		// Draw the circle (optional)

		circle(imageCopy5, center, static_cast<int>(radius), cv::Scalar(255), 5);
		circle(imageCopy5, center, 5,cv::Scalar(0, 0, 255), -1);

	}

	cv::imwrite("./Coin/DetectedCoinPerfectOne.png", imageCopy5);


	
	cv::waitKey();

}
