#include"DetectionHeader.hpp"


void areaAndArcLength(std::vector<std::vector<cv::Point>> Contour) {
	double area;
	double perimeter;
	std::cout << std::endl;
	for (size_t i = 0; i < Contour.size(); i++) {
		area = cv::contourArea(Contour[i]);
		perimeter = cv::arcLength(Contour[i], true);
		std::cout << "Contour #" << i + 1 << " has area = " << area << " and perimeter = " << perimeter << std::endl;
	}
}