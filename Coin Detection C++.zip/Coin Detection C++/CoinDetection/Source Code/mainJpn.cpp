#include"DetectionHeader.hpp"
#include<vector>
#include<string>

using cv::Mat;
using std::cout;

int main() {
	std::string Path = "./Resourses/CoinsB.png";
	Mat CoinB = cv::imread(Path);
	cv::resize(CoinB, CoinB, cv::Size(1200, 720));
	//cv::imshow("CoinB", CoinB);
	Mat CoinBGray;
	cv::cvtColor(CoinB, CoinBGray, cv::COLOR_BGR2GRAY);
	//cv::imshow("GrayCoins", CoinBGray);

	std::vector<Mat> channels2;
	cv::split(CoinB, channels2);

	/*std::string windoname = "Channels";
	for (int i = 0; i < channels2.size(); i++) {
		cv::imshow(windoname + std::to_string(i), channels2[i]);
	}
 */

	//perfoming ThreshHolding
	Mat srcjpn = CoinBGray.clone();
	Mat dstjpn;
	int threshjpn = 145;
	int maxValuejpn = 255;
	threshold(srcjpn, dstjpn, threshjpn, maxValuejpn, cv::THRESH_BINARY);

	//cv::imshow("thresh_Binary_1", dstjpn);
	cv::imwrite("./Coin/CoinJPN/thresh_Binary_1.png", dstjpn);
	

	//performing Morphological Operation
	  

	//Kernel Size = 5 , Morph_Cross;
	int kSizejpn = 5;
	Mat kerneljpn = getStructuringElement(cv::MORPH_CROSS,
		cv::Size(kSizejpn, kSizejpn));
	Mat imageDilatedjpn;

	dilate(dstjpn, imageDilatedjpn, kerneljpn);

	//cv::imshow("DilatedImage", imageDilatedjpn);
	cv::imwrite("./Coin/CoinJPN/DilatedImage_2.png", imageDilatedjpn);

	//performing Erotion kernel Size = 9 , MORPH_RECTANGLE;

	int kSizejpn2 = 9;
	Mat kerneljpn2 = cv::getStructuringElement(cv::MORPH_RECT, cv::Size(kSizejpn2, kSizejpn2));
	Mat imageErodeJPN;
	cv::erode(imageDilatedjpn, imageErodeJPN, kerneljpn2);

	//cv::imshow("erodeImage_3", imageErodeJPN);
	cv::imwrite("./Coin/CoinJPN/erodedImage_3.png", imageErodeJPN);


	//performing Erotion kernel Size = 10 , MORPH_RECTANGLE
	int kSizejpn3 = 10;
	Mat kerneljpn3 = getStructuringElement(cv::MORPH_RECT,
		cv::Size(kSizejpn3, kSizejpn3));
	Mat imageErodejpn2;
	erode(imageErodeJPN, imageErodejpn2, kerneljpn3);

	//cv::imshow("AgainErotion", imageErodejpn2);
	cv::imwrite("./Coin/CoinJPN/AgainErotion_4.png", imageErodejpn2);


	//perfoming Closing KernelSize = 6, Morph_ELLIPSE
	int closingSizejpn = 6;
	// Selecting a elliptical kernel 
	Mat elementjpn5 = cv::getStructuringElement(cv::MORPH_ELLIPSE, cv::Size(2 * closingSizejpn + 1, 2 * closingSizejpn + 1),
		cv::Point(closingSizejpn, closingSizejpn));

	Mat ClosingJPN;
	morphologyEx(imageErodejpn2, ClosingJPN, cv::MORPH_CLOSE, elementjpn5, cv::Point(-1, -1), 3);
	
	//cv::imshow("Closing", ClosingJPN);
	cv::imwrite("./Coin/CoinJPN/Closing_5.png", ClosingJPN);


	//performing Opening Kernel size 8;

	int OpeningSizejpn2 = 4;


	// Selecting a elliptical kernel 
	Mat elementjpn6 = cv::getStructuringElement(cv::MORPH_RECT, cv::Size(2 * OpeningSizejpn2 + 1, 2 * OpeningSizejpn2 + 1),
		cv::Point(OpeningSizejpn2, OpeningSizejpn2));

	Mat OpeningJPN;
	morphologyEx(ClosingJPN, OpeningJPN, cv::MORPH_OPEN, elementjpn6, cv::Point(-1, -1), 3);
	//cv::imshow("Opening", OpeningJPN);
	cv::imwrite("./Coin/CoinJPN/Opening_6.png", OpeningJPN);


	Mat imageJPNfinal;
	bitwise_not(OpeningJPN, imageJPNfinal);
	//cv::imshow("InversingImage", imageJPNfinal);
	cv::imwrite("./Coin/CoinJPN/InversingImage_7.png", imageJPNfinal);


	//blob detector
	cv::SimpleBlobDetector::Params params;

	// Setup SimpleBlobDetector parameters.

	params.blobColor = 0;

	params.minDistBetweenBlobs = 2;

	// Filter by Area
	params.filterByArea = false;

	// Filter by Circularity
	params.filterByCircularity = true;
	params.minCircularity = 0.8;

	// Filter by Convexity
	params.filterByConvexity = true;
	params.minConvexity = 0.8;

	// Filter by Inertia
	params.filterByInertia = true;
	params.minInertiaRatio = 0.8;

	// Set up detector with params
	cv::Ptr<cv::SimpleBlobDetector> detector = cv::SimpleBlobDetector::create(params);
	std::vector<cv::KeyPoint> keypoints;
	detector->detect(OpeningJPN, keypoints);

	cout<<std::endl << "Number of coin detected =" << keypoints.size()<<"\n";
	//displaying DetectedCoins
	cv::Mat DetectedCoin = DisplayDetected(CoinB, keypoints);
	//cv::imshow("detectedCoin", DetectedCoin);
	cv::imwrite("./Coin/CoinJPN/Detected_Coin_8.png", DetectedCoin);

	//Connected Component Analysis

	Mat colorMapJPN = displayConnectedComponents(imageJPNfinal);
	//cv::imshow("colorMapJPN", colorMapJPN);
	cv::imwrite("./Coin/CoinJPN/ConnectedComponent_9.png", colorMapJPN);

	//detecting Coin Using Contour detection
	std::vector<std::vector<cv::Point>> contoursJPN;
	std::vector<cv::Vec4i> hierarchyJPN;

	findContours(OpeningJPN, contoursJPN, hierarchyJPN,cv::RETR_LIST, cv::CHAIN_APPROX_SIMPLE);
	cout<<"\n" << "Number of contours found = " << contoursJPN.size()<<"\n";


	Mat imageCopyJPN2 = CoinB.clone();

	drawContours(imageCopyJPN2, contoursJPN, -1, cv::Scalar(0, 255, 0), 10);

	//cv::imshow("notPerfectDetectedCoin", imageCopyJPN2);
	cv::imwrite("./Coin/CoinJPN/notPerfectDetectedCoin_10.png", imageCopyJPN2);


	std::vector<std::vector<cv::Point>> contoursJPN1;
	std::vector<cv::Vec4i> hierarchyJPN1;
	Mat imageCopyJPN3 = CoinB.clone();
	Mat CopyGrayJPN3 = OpeningJPN.clone();
	findContours(CopyGrayJPN3, contoursJPN1, hierarchyJPN1, cv::RETR_EXTERNAL, cv::CHAIN_APPROX_SIMPLE);
	drawContours(imageCopyJPN3, contoursJPN1, -1, cv::Scalar(0, 255, 0), 10);
	cout <<"\n" << "Number of contour found =" << contoursJPN1.size()<<"\n";

	cv::imshow("externalContours", imageCopyJPN3);
	cv::imwrite("./Coin/CoinJPN/externalContours_11.png", imageCopyJPN3);

	//printing Area and Arc Of Contours as perimeter

	areaAndArcLength(contoursJPN);
	maxAreaOfContour(contoursJPN);

	cout <<"\n" << contoursJPN.size()<<"\n";
	contoursJPN.erase(contoursJPN.begin() + 12);
	cout << "\n" << contoursJPN.size() << "\n";
	contoursJPN.erase(contoursJPN.begin() + 5, contoursJPN.begin() + 7);
	cout << "\n" << contoursJPN.size() << "\n";

	areaAndArcLength(contoursJPN);

	Mat imageCopyJPN5 = CoinB.clone();
	drawContours(imageCopyJPN5, contoursJPN, -1, cv::Scalar(0, 255, 0), 10);

	cv::imshow("notPefectDetectedContour", imageCopyJPN5);
	cv::imwrite("./Coin/CoinJPN/notPefectDetectedContour_12.png", imageCopyJPN5);


	Mat imageCopyJPN6 = CoinB.clone();
	for (const auto& contour : contoursJPN) {
		cv::Point2f center1;
		float radius1;
		minEnclosingCircle(contour, center1, radius1);

		// Draw the circle (optional)

		circle(imageCopyJPN6, center1, static_cast<int>(radius1), cv::Scalar(255), 11);
		circle(imageCopyJPN6, center1, 11, cv::Scalar(0, 0, 255), -1);
	}
	cv::imshow("perfectDetectedContours", imageCopyJPN6);
	cv::imwrite("./Coin/CoinJPN/perfectDetectedContours_13.png", imageCopyJPN6);


	cv::waitKey();

	
}