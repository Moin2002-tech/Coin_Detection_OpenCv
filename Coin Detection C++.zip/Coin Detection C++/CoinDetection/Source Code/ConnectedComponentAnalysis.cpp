#include"DetectionHeader.hpp"

cv::Mat displayConnectedComponents(cv::Mat& im)
{
	// Make a copy of the image
	cv::Mat imLabels = im.clone();

	// First let's find the min and max values in imLabels
	cv::Point minLoc, maxLoc;
	double min, max;

	// The following line finds the min and max pixel values
	// and their locations in an image.
	minMaxLoc(imLabels, &min, &max, &minLoc, &maxLoc);

	// Normalize the image so the min value is 0 and max value is 255.
	imLabels = 255 * (imLabels - min) / (max - min);

	// Convert image to 8-bits
	imLabels.convertTo(imLabels, CV_8U);

	// Apply a color map
	cv::Mat imColorMap;
	applyColorMap(imLabels, imColorMap, cv::COLORMAP_JET);

	return imColorMap;
}