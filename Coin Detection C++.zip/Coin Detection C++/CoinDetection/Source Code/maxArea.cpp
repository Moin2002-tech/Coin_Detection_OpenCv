#include"DetectionHeader.hpp"


void maxAreaOfContour(std::vector<std::vector<cv::Point>> Contours) {

	double maxArea = 0;
	int maxAreaContourIdx = -1;
	for (size_t i = 0; i < Contours.size(); ++i) {
		double area = cv::contourArea(Contours[i]);
		if (area > maxArea) {
			maxArea = area;
			maxAreaContourIdx = static_cast<int>(i);
		}
	}

	if (maxAreaContourIdx >= 0) {
		std::cout<<"\n" << "Largest contour area: " << maxArea << std::endl;
	}
	else {
		std::cout << "\n " << "No contours found!" << std::endl;
	}

}