

#include"DetectionHeader.hpp"


cv::Mat DisplayDetected(cv::Mat Image,std::vector<cv::KeyPoint> Keypoints) {

	int x, y;
	int radius;
	double diameter;
	cv::Mat imageCopy1 = Image.clone();

	for (size_t i = 0; i < Keypoints.size(); i++) {
		x = static_cast<int>(Keypoints[i].pt.x);
		y = static_cast<int>(Keypoints[i].pt.y);
		diameter = Keypoints[i].size;


		radius = static_cast<int>(diameter / 2.0);


		circle(imageCopy1, cv::Point(x, y), radius, cv::Scalar(0, 255, 0), 5);


		circle(imageCopy1, cv::Point(x, y), 5, cv::Scalar(0, 0, 255), -1);

		
	}

	return imageCopy1;
}